import React,{ useState } from 'react';

import * as TodoActions from '../../Actions/TodoActions';
import '../../App.css';

function CreateTodo(){
	const [title, setTitle] = useState("");
	const handleChange = (e)=>{
        setTitle(e.target.value);
    }
	const createTodo = ()=>{
        TodoActions.createTodo(title);
        setTitle("");
    }
    return (<div>New todo: <input type="text" value={title} onChange={handleChange} />
        	<button type="button" onClick={createTodo}>Add</button></div>);
}

export default CreateTodo;