import React, {useEffect, useState} from 'react';

import TodoStore from '../../Stores/TodoStore';
import Todo from './Todo';
import CreateTodo from './CreateTodo';

function Todos(){
	const [todoState, setTodoState] = useState([]);

	//
	const onChangeTodos = () => {
		const allTodos = TodoStore.getAll();
		setTodoState([...allTodos]);
    };

	useEffect(()=>{
		const todoList = TodoStore.getAll();
		setTodoState(todoList);
		TodoStore.on("change", onChangeTodos);
        return (()=>{
        	TodoStore.removeListener("change", onChangeTodos);
        });

	},[]);

	return (
		<div className={'Todo-List'}>
			<h1>My todos</h1>
        	<hr/>
        	<ul style={{listStyleType:"none" }}>
        		{todoState.map((todo, i) =>
    				<Todo key={todo.id} {...todo} todoIndex={i} />
				)}
    		</ul>
        	<CreateTodo />
		</div>);
}


export default Todos; 
