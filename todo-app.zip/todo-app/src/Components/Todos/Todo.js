import React from 'react';
import { FaCheckCircle, FaCircle, FaTrashAlt} from 'react-icons/fa';
import { FiCheck } from "react-icons/fi";

import * as TodoActions from '../../Actions/TodoActions';
import '../../App.css';

function Todo(props){
	const removeTodo =(id)=>{
		TodoActions.removeTodo(id);
	};
	const doneTodo = (id)=>{
		TodoActions.doneTodo(id);
	}
	return (<li>
		{props.completed ? <FaCheckCircle/> : <FaCircle/>} {props.title} 
		{(!props.completed) ? <button onClick={()=>{doneTodo(props.todoIndex)}} className="Todo-button"  type="button"><FiCheck /></button> : ''} 
		<button className="Todo-button" onClick={()=>{removeTodo(props.id)}} type="button"><FaTrashAlt /></button> 
	</li>);
}

export default Todo; 